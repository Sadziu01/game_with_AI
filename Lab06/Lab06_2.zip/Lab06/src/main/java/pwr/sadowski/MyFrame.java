package pwr.sadowski;

import java.awt.*;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;


public class MyFrame extends JFrame {

	private JPanel contentPane;
	JPanel menuPanel = new JPanel();
	static MyPanel hostPanel = new MyPanel();
	static MyPanel playerPanel = new MyPanel();
	
	CardLayout cl = new CardLayout();
	JButton hostButton = new JButton("HostApp");
	JButton playerButton = new JButton("PlayerApp");

	Host host;


	/**
	 * Create the frame.
	 */
	public MyFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 775, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(cl);
				
		
		menuPanel.setBounds(10, 10, 414, 240);
		contentPane.add("1", menuPanel);
		menuPanel.setBackground(new Color(70, 163, 255));
		menuPanel.setLayout(null);
		hostButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		hostButton.setBounds(232, 284, 308, 40);
		menuPanel.add(hostButton);

		hostButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(contentPane, "2");
				host = new Host();
				host.start();
			}
		});
		playerButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		
		playerButton.setBounds(232, 360, 308, 40);
		menuPanel.add(playerButton);

		playerButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(contentPane, "3");

				createPlayer();

			}
		});

		
		
		hostPanel.setBounds(10, 11, 414, 239);
		contentPane.add("2", hostPanel);
		hostPanel.setBackground(Color.GREEN);
		hostPanel.setLayout(null);


		
		playerPanel.setBounds(10, 11, 414, 239);
		contentPane.add("3", playerPanel);
		playerPanel.setBackground(Color.YELLOW);
		playerPanel.setLayout(null);
		
		cl.show(contentPane, "1");
	}


	public void createPlayer(){
		int tempPort = new Random().nextInt(1000);

		if(Host.uniquePorts.contains(tempPort)){
			createPlayer();
		}
		else {
			Host.uniquePorts.add(tempPort);
			Player player = new Player(tempPort);

			player.start();
		}
	}
}
