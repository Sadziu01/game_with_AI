package pwr.sadowski;

abstract class Map {
    Position cords = new Position(100, 150);

    char[][] map = new char[cords.getY()][cords.getX()];


//    public int getMapY() {
//        return mapY;
//    }
//
//    public void setMapY(int mapY) {
//        this.mapY = mapY;
//    }
//
//    public int getMapX() {
//        return mapX;
//    }
//
//    public void setMapX(int mapX) {
//        this.mapX = mapX;
//    }
}
