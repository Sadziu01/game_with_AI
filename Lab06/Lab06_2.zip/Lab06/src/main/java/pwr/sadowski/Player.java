package pwr.sadowski;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Random;

import static java.lang.Thread.sleep;
import static pwr.sadowski.MyFrame.playerPanel;

public class Player extends Map{
    private final int individualPort;
    private Thread t = null;
    private Thread t2 = null;
    private ServerSocket s = null;

    public Player(int individualPort){
        this.individualPort = individualPort;
        cords.setY(new Random().nextInt(cords.getY()));
        cords.setX(new Random().nextInt(cords.getX()));

        map();
    }

    public void map(){
        for(int y = 0; y < 100; y++){
            for (int x = 0; x < 150; x++) {
                map[y][x] = ' ';
            }
        }
        map[cords.getY()][cords.getX()] = 'P';
        playerPanel.setMap(map);
    }


    public synchronized void send(String type, String message, String host, int port){
        Socket s;
        try{
            s = new Socket(host, port);
            OutputStream out = s.getOutputStream();
            PrintWriter pw = new PrintWriter(out, false);

            pw.println(type + ";" + message);

            pw.flush();
            pw.close();
            s.close();
        }catch (UnknownHostException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }


    public void start(){
        t = new Thread(() -> {
                try {
                    s = new ServerSocket(individualPort);
                    while (true){
                        String flag;
                        Socket sc = s.accept();
                        InputStream is = sc.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);

                        String theLine = br.readLine();

                        String[] splitedArray;
                        splitedArray = theLine.split(";");

                        flag = splitedArray[0];

                            if(flag.equals("sb")){
                                int k = 1;
                                for (int i = -1; i < 2; i++) {
                                    for (int j = -1; j < 2; j++) {
                                        map[cords.getY() + i][cords.getX() + j] = splitedArray[k].charAt(0);
                                        k++;
                                    }
                                }
                                playerPanel.repaint();
                            }

                            if(flag.equals("mb")){
                                String result = splitedArray[1];
                                
                                if(result.equals("T")){
                                    cords.setY(Integer.parseInt(splitedArray[2]));
                                    cords.setX(Integer.parseInt(splitedArray[3]));

                                }
                                else if (result.equals("F")) {
                                    
                                }


                            }

                            if(flag.equals("mb")){

                            }

                            sc.close();
                    }
                }catch (SocketException e){

                }catch (IOException e){
                    e.printStackTrace();
                }
        });
        t.start();


        t2 = new Thread(() -> {
            String tempMess;

            while (true){
                tempMess = individualPort + ";" + cords.getY() + ";" + cords.getX();
                send("ss", tempMess, "localhost", 2000);
                doDelay();

                var pos = new Position(cords.getY(), cords.getX());
                move(pos);

                tempMess = individualPort + ";" + cords.getY() + ";" + cords.getX() + ";" + pos.getY() + ";" + pos.getX();
                send("ms", tempMess, "localhost", 2000);
                doDelay();

                tempMess = individualPort + ";" + cords.getY() + ";" + cords.getX();
                send("ss", tempMess, "localhost", 2000);

                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        t2.start();

    }


    protected Position move(Position position){
        int direction = new Random().nextInt(8);
        switch (direction){
            case 0:
                position.setY(position.getY() - 1);
                break;
            case 1:
                position.setX(position.getX() - 1);
                break;
            case 2:
                position.setY(position.getY() + 1);
                break;
            case 3:
                position.setX(position.getX() + 1);
            case 4:
                position.setY(position.getY() - 1);
                position.setX(position.getX() - 1);
                break;
            case 5:
                position.setY(position.getY() - 1);
                position.setX(position.getX() + 1);
                break;
            case 6:
                position.setY(position.getY() + 1);
                position.setX(position.getX() - 1);
                break;
            case 7:
                position.setY(position.getY() + 1);
                position.setX(position.getX() + 1);
                break;
        }
        return position;
    }

    protected void doDelay(){
        try {
            sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args){


    }
}
