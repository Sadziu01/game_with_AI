module Lab {
	requires java.desktop;
}