package pwr.sadowski;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.*;

import java.util.List;

import static pwr.sadowski.MyFrame.hostPanel;

public class Host extends Map{
    public static HashSet<Integer> uniquePorts = new HashSet<>();


    private Thread t = null;
    private int port = 2000;
    private ServerSocket s = null;

    Host(){
        map_initialization();
    }

    public void map_initialization(){
        for(int y = 0; y < 100; y++){
            for (int x = 0; x < 150; x++) {
                map[y][x] = 'E';
            }
        }
        tree_generate(20);
        tresure_generate(70);

        hostPanel.setMap(map);
    }

    private void tree_generate(int amount){
        List<Integer> rocks = Arrays.asList(3, 4, 4, 4, 4, 4, 3);
        for (int i = 0; i < amount; i++) {
            int y = new Random().nextInt(mapY);
            int x = new Random().nextInt(mapX);
            for (Integer pixels : rocks) {
                int l = x, r = x;
                for (int j = 0; j < pixels; j++) {
                    if(y < mapY && l >= 0){
                        map[y][l] = 'R';
                    }
                    if(y < mapY && r < mapX){
                        map[y][r] = 'R';
                    }
                    l--;
                    r++;
                }
                y++;
            }
        }
    }

    private void tresure_generate(int amount){
        for (int i = 0; i < amount; i++) {
            int y = new Random().nextInt(mapY);
            int x = new Random().nextInt(mapX);

            if(map[y][x] == 'E'){
                map[y][x] = 'T';
            }
            else {
                tresure_generate(1);
            }
        }
    }

    public void start(){
        t = new Thread(() -> {
            try{
                s = new ServerSocket(2000);
                while (true){
                    String flag;
                    int portToSend;
                    String messageToSend;
                    Socket sc = s.accept();
                        InputStream is = sc.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);

                        String theLine = br.readLine();

                        String[] splitedArray = null;
                        splitedArray = theLine.split(";");


                        flag = splitedArray[0];
                        portToSend = Integer.parseInt(splitedArray[1]);

                        int y = Integer.parseInt(splitedArray[2]);
                        int x = Integer.parseInt(splitedArray[3]);

                        List<String> tempCharList = new ArrayList<>();



                        //TODO ss
                        if(flag.equals("ss")){

                            map[y][x] = 'P';
                            hostPanel.repaint();

                            for (int i = -1; i < 2; i++) {
                                for (int j = -1; j < 2; j++) {
                                    tempCharList.add(String.valueOf(map[y + i][x + j]));
                                }
                            }

                            messageToSend = tempCharList.get(0) + ";" + tempCharList.get(1) + ";" + tempCharList.get(2) + ";" + tempCharList.get(3) + ";" + tempCharList.get(4) +
                                    ";" + tempCharList.get(5) + ";" + tempCharList.get(6) + ";" + tempCharList.get(7) + ";" + tempCharList.get(8);

                            Socket s;
                            try{
                                s = new Socket("localhost", portToSend);
                                OutputStream out = s.getOutputStream();
                                PrintWriter pw = new PrintWriter(out, false);

                                pw.println("sb;" + messageToSend);

                                pw.flush();
                                pw.close();
                                s.close();
                            }catch (UnknownHostException e){
                                e.printStackTrace();
                            }catch (IOException e){
                                e.printStackTrace();
                            }

                        }


                        //TODO ms
                        if(flag.equals("ms")){
                            int nextY = Integer.parseInt(splitedArray[4]);
                            int nextX = Integer.parseInt(splitedArray[5]);

                            if(map[nextY][nextX] == 'E'){
                                map[y][x] = 'E';
                                map[nextY][nextX] = 'P';
                                hostPanel.repaint();

                                messageToSend = "T;" + y + ";" + x;
                            }
                            else{
                                messageToSend = "F";
                            }

                            Socket s;
                            try{
                                s = new Socket("localhost", portToSend);
                                OutputStream out = s.getOutputStream();
                                PrintWriter pw = new PrintWriter(out, false);

                                pw.println("mb;" + messageToSend);

                                pw.flush();
                                pw.close();
                                s.close();
                            }catch (UnknownHostException e){
                                e.printStackTrace();
                            }catch (IOException e){
                                e.printStackTrace();
                            }
                        }



                        if(flag.equals("ts")){

                        }

                        sc.close();
                }
            }catch (SocketException e){

            }catch (IOException e){
                e.printStackTrace();
            }
        });
        t.start();
    }
}
