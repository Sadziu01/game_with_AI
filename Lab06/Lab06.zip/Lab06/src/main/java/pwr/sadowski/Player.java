package pwr.sadowski;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Random;

import static pwr.sadowski.MyFrame.playerPanel;

public class Player extends Map{
    private final int individualPort;
    private Thread t = null;
    private Thread t2 = null;
    private ServerSocket s = null;


    public Player(int individualPort){
        this.individualPort = individualPort;
        mapY = new Random().nextInt(mapY);
        mapX = new Random().nextInt(mapX);

        map();
    }

    public void map(){
        for(int y = 0; y < 100; y++){
            for (int x = 0; x < 150; x++) {
                map[y][x] = ' ';
            }
        }
        map[mapY][mapX] = 'P';
        playerPanel.setMap(map);
    }


    public void send(String type, String message, String host, int port){
        Socket s;
        try{
            s = new Socket(host, port);
            OutputStream out = s.getOutputStream();
            PrintWriter pw = new PrintWriter(out, false);

            pw.println(type + ";" + message);

            pw.flush();
            pw.close();
            s.close();
        }catch (UnknownHostException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }


    public void start(){
        t = new Thread(() -> {
                try {
                    s = new ServerSocket(individualPort);
                    while (true){
                        String flag;
                        Socket sc = s.accept();
                        InputStream is = sc.getInputStream();
                        InputStreamReader isr = new InputStreamReader(is);
                        BufferedReader br = new BufferedReader(isr);

                        String theLine = br.readLine();

                        String[] splitedArray = null;
                        splitedArray = theLine.split(";");

                        flag = splitedArray[0];

                            if(flag.equals("sb")){
                                int k = 1;
                                for (int i = -1; i < 2; i++) {
                                    for (int j = -1; j < 2; j++) {
                                        map[mapY + i][mapX + j] = splitedArray[k].charAt(0);
                                        k++;
                                    }
                                }
                                playerPanel.repaint();
                            }

                            if(flag.equals("mb")){
                                String result = splitedArray[1];
                                
                                if(result.equals("T")){
                                    int y = Integer.parseInt(splitedArray[2]);
                                    int x = Integer.parseInt(splitedArray[3]);

                                    mapY = y;
                                    mapX = x;
                                }
                                else if (result.equals("F")) {
                                    
                                }


                            }

                            if(flag.equals("mb")){

                            }

                            sc.close();
                    }
                }catch (SocketException e){

                }catch (IOException e){
                    e.printStackTrace();
                }
        });
        t.start();


        t2 = new Thread(() -> {
            String tempMess;

            while (true){
                tempMess = individualPort + ";" + mapY + ";" + mapX;
                send("ss", tempMess, "localhost", 2000);

                int nextY = mapY, nextX = mapX;

                move(nextY, nextX);

                tempMess = individualPort + ";" + mapY + ";" + mapX + ";" + nextY + ";" + nextX;
                send("ms", tempMess, "localhost", 2000);

                send("ss", tempMess, "localhost", 2000);
            }
        });
        t2.start();

    }


    protected void move(int y, int x){
        int direction = new Random().nextInt(8);
        switch (direction){
            case 0:
                y -= 1;
                break;
            case 1:
                x -= 1;
                break;
            case 2:
                y += 1;
                break;
            case 3:
                x += 1;
            case 4:
                y -= 1;
                x -= 1;
                break;
            case 5:
                y -= 1;
                x += 1;
                break;
            case 6:
                y += 1;
                x -= 1;
                break;
            case 7:
                y += 1;
                x += 1;
                break;
        }
    }

//    protected void move(){
//        int direction = new Random().nextInt(8);
//        switch (direction){
//            case 0:
//                setMapY(getMapY() - 1);
//                break;
//            case 1:
//                setMapX(getMapX() - 1);
//                break;
//            case 2:
//                setMapY(getMapY() + 1);
//                break;
//            case 3:
//                setMapX(getMapX() + 1);
//            case 4:
//                setMapY(getMapY() - 1);
//                setMapX(getMapX() - 1);
//                break;
//            case 5:
//                setMapY(getMapY() - 1);
//                setMapX(getMapX() + 1);
//                break;
//            case 6:
//                setMapY(getMapY() + 1);
//                setMapX(getMapX() - 1);
//                break;
//            case 7:
//                setMapY(getMapY() + 1);
//                setMapX(getMapX() + 1);
//                break;
//        }
//    }



    public static void main(String[] args){


    }
}
